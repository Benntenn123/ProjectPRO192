
package Classes;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;


public class BrandList {
    
    ArrayList<Brand> bList;
    
    public BrandList() {
        bList = new ArrayList<>();
    }
    
    public boolean loadFromFile(String fileName) throws FileNotFoundException, IOException {
        File f = new File(fileName);
        if (!f.exists()) return false;
        
        BufferedReader br = new BufferedReader(new FileReader(f));
        while (true) {
            String line = br.readLine();
            if (line == null) 
                break;
                                                //      B5-18, BMW 530i (2018), Alpine: 2.599
            line = line.replace(':', ',');      //  ->  B5-18, BMW 530i (2018), Alpine, 2.599
                                                
            String[] data = line.split(",");    // ["B5-18", "BMW 530i (2018)", "Alpine", "2.599"]
            Brand b = new Brand(data[0], data[1], data[2], Double.parseDouble(data[3]));
            bList.add(b);
        }
        
        br.close();
        return true;
    }
    
    public boolean saveToFile(String fileName) throws IOException {
        File f = new File(fileName);
        try (FileWriter fw = new FileWriter(f)) {
            for (Brand b : bList) {
                fw.write(b.toString() + "\n");
            }
            fw.close();
        } catch (Exception ex) {
            return false;
        }
        
        return true;
    }
    
    public int searchID(String bID) {
        for (int i = 0; i < bList.size(); i++) {
            if (bList.get(i).getBrandID().equalsIgnoreCase(bID))
                return i;
        }        
        return -1;
    }
    
    public Brand getUserChoice() {
        ArrayList<Brand> options = new ArrayList<>();
        for (Brand b : bList) options.add(b);
        Menu mnu = new Menu();
        return (Brand) mnu.ref_getChoice(options);
    }
    
    public void addBrand() {
        Scanner sc = new Scanner(System.in);
        String id, name, sound;
        double price;
        while (true) {
            System.out.print("Enter brand ID: ");
            id = sc.nextLine();
            // Check if ID already in brandList
            // If not exist, accept ID and break the loop
            if (searchID(id) == -1) break;
            System.out.println("Please re-enter. Cannot add existing ID");
        }
        
        while (true) {
            System.out.print("Enter brand name: ");
            name = sc.nextLine();
            // Check if name is blank
            if (!name.isEmpty()) break;
            System.out.println("Please re-enter. Brand name cannot be blank");            
        }
        
        while (true) {
            System.out.print("Enter sound brand: ");
            sound = sc.nextLine();
            if (!sound.isEmpty()) break;
            System.out.println("Please re-enter. Sound brand cannot be blank");
        }
        
        while (true) {
            System.out.print("Enter price: ");
            // try-catch to handle input String case
            try {
                price = Double.parseDouble(sc.nextLine());
                if (price > 0) break;
                throw new NumberFormatException();
            } catch (NumberFormatException ex) {
                System.out.println("Please re-enter. Price must be positive real number");
            }
        }
        
        bList.add(new Brand(id, name, sound, price));
    }
    
    public void updateBrand() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter brand ID to update: ");
        String id = sc.nextLine();
        int pos = searchID(id);
        if (pos == -1) {
            System.out.println("Not found!");
            return;
        }
        
        String name, sound;
        double price;
        while (true) {
            System.out.print("Enter brand name: ");
            name = sc.nextLine();
            // Check if name is blank
            if (!name.isEmpty()) break;
            System.out.println("Please re-enter. Brand name cannot be blank");            
        }
        
        while (true) {
            System.out.print("Enter sound brand: ");
            sound = sc.nextLine();
            if (!sound.isEmpty()) break;
            System.out.println("Please re-enter. Sound brand cannot be blank");
        }
        
        while (true) {
            System.out.print("Enter price: ");
            // try-catch to handle input String case
            try {
                price = Double.parseDouble(sc.nextLine());
                if (price > 0) break;
                throw new NumberFormatException();
            } catch (NumberFormatException ex) {
                System.out.println("Please re-enter. Price must be positive real number");
            }
        }
        
        bList.set(pos, new Brand(id, name, sound, price));
    }
    
    public void listBrands() {
        for (Brand b : bList)
            System.out.println(b);
    }
    
}
