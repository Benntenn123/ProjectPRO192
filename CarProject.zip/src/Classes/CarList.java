
package Classes;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class CarList {

    ArrayList<Car> cList;
    BrandList brandList;

    public CarList(BrandList bList) {
        cList = new ArrayList<>();
        brandList = bList;
    }

    public boolean loadFromFile(String fileName) throws FileNotFoundException, IOException {
        File f = new File(fileName);
        if (!f.exists()) {
            return false;
        }

        BufferedReader br = new BufferedReader(new FileReader(f));
        while (true) {
            String line = br.readLine();
            if (line == null) {
                break;
            }
            String[] data = line.split(",");        // ["C01", "B7-2018", "red", "F12345", "E12345"] 
            int pos = brandList.searchID(data[1].trim());
            Brand b = brandList.bList.get(pos);     // Find Brand from brand ID 
            cList.add(new Car(data[0], b, data[2], data[3], data[4]));
        }

        br.close();
        return true;
    }

    public boolean saveToFile(String fileName) throws IOException {
        File f = new File(fileName);
        try (FileWriter fw = new FileWriter(f)) {
            for (Car c : cList) {
                fw.write(c + "\n");
            }
            fw.close();
        } catch (Exception ex) {
            return false;
        }

        return true;
    }

    public int searchID(String carID) {
        for (int i = 0; i < cList.size(); i++) {
            if (cList.get(i).getCarID().equalsIgnoreCase(carID)) {
                return i;
            }
        }

        return -1;
    }

    public int searchFrame(String fID) {
        for (int i = 0; i < cList.size(); i++) {
            if (cList.get(i).getFrameID().equalsIgnoreCase(fID)) {
                return i;
            }
        }

        return -1;
    }

    public int searchEngine(String eID) {
        for (int i = 0; i < cList.size(); i++) {
            if (cList.get(i).getEngineID().equalsIgnoreCase(eID)) {
                return i;
            }
        }

        return -1;
    }

    public void addCar() {
        Scanner sc = new Scanner(System.in);
        String carID, color, frameID, engineID;

        while (true) {
            System.out.print("Enter car ID: ");
            carID = sc.nextLine();
            // Check if ID already in carList
            // If not exist, accept ID and break the loop
            if (searchID(carID) == -1) {
                break;
            }
            System.out.println("Please re-enter. Cannot add existing ID");
        }

        Menu m = new Menu();
        Brand b = (Brand) m.ref_getChoice(brandList.bList);

        while (true) {
            System.out.print("Enter color: ");
            color = sc.nextLine();
            // Check if color is blank
            if (!color.isEmpty()) {
                break;
            }
            System.out.println("Please re-enter. Color cannot be blank");
        }

        while (true) {
            System.out.print("Enter frame ID: ");
            frameID = sc.nextLine();
            // Regex check               Duplicate check
            if (frameID.matches("F[0-9]{5}") && searchFrame(frameID) == -1) {
                break;
            }
            System.out.println("Please re-enter. Frame ID must be in the \"F00000\" format and not be duplicated");
        }

        while (true) {
            System.out.print("Enter engine ID: ");
            engineID = sc.nextLine();
            // Regex check               Duplicate check
            if (engineID.matches("E[0-9]{5}") && searchEngine(engineID) == -1) {
                break;
            }
            System.out.println("Please re-enter. Engine ID must be in the \"E00000\" format and not be duplicated");
        }

        cList.add(new Car(carID, b, color, frameID, engineID));
        System.out.println("Add successfully");
    }

    public void printBasedBrandName() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter part of brand name: ");
        String part = sc.nextLine();
        int count = 0;
        for (Car c : cList) {
            if (c.getBrand().getBrandName().contains(part)) {
                System.out.println(c.screenString());
                count++;
            }
        }

        if (count == 0) {
            System.out.println("No car is detected!");
        }
    }

    public boolean removeCar() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter removed ID: ");
        String removedID = sc.nextLine();
        int pos = searchID(removedID);
        if (pos == -1) {
            System.out.println("Not found!");
            return false;
        } else {
            cList.remove(pos);
            System.out.println("Remove successfully");
            return true;
        }
    }

    public boolean updateCar() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter updated ID: ");
        String updatedID = sc.nextLine();
        int pos = searchID(updatedID);
        if (pos == -1) {
            System.out.println("Not found!");
            return false;
        } else {
            Menu m = new Menu();
            Brand b = (Brand) m.ref_getChoice(brandList.bList);
            String color, frameID, engineID;
            while (true) {
                System.out.print("Enter color: ");
                color = sc.nextLine();
                // Check if color is blank
                if (!color.isEmpty()) {
                    break;
                }
                System.out.println("Please re-enter. Color cannot be blank");
            }

            while (true) {
                System.out.print("Enter frame ID: ");
                frameID = sc.nextLine();
                                // Regex check               Duplicate check
                if (frameID.matches("F[0-9]{5}") && searchFrame(frameID) == -1) {
                    break;
                }
                System.out.println("Please re-enter. Frame ID must be in the \"F00000\" format and not be duplicated");
            }

            while (true) {
                System.out.print("Enter engine ID: ");
                engineID = sc.nextLine();
                                // Regex check               Duplicate check
                if (engineID.matches("E[0-9]{5}") && searchEngine(engineID) == -1) {
                    break;
                }
                System.out.println("Please re-enter. Engine ID must be in the \"E00000\" format and not be duplicated");
            }
            
            cList.set(pos, new Car(updatedID, b, color, frameID, engineID));
            System.out.println("Update successfully");
            return true;
        }
    }
    
    public void listCars() {
        Collections.sort(cList);
        for (Car c : cList)
            System.out.println(c.screenString());
    }
    
}
